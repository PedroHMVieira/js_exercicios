function encontrarmaiorElemento (array){
return Math.max(...array)
}

console.log(encontrarmaiorElemento([10,20,30,50,48]));