function somaElementospares(array){
    let soma=0;
    for(let i=0; i<=array.length; i++){
        if(array[i]%2==0){
            soma=soma+array[i];
        }
    }
    return soma
}

console.log(somaElementospares([10,15,16,18,10]));