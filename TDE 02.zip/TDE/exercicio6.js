const gerarLista = (n, funcaoGeracao) => {
    const lista = [];
    for (let index = 0; index < n; index++) {
        lista.push(funcaoGeracao(index));
    }
    return lista;
};


const gerarNumeroMaisUm = (index) => {
    return index + 1;
};

const listaNumeros = gerarLista(5, gerarNumeroMaisUm);
console.log(listaNumeros);