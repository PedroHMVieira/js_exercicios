const filtrarArray = (arr, callback) => {
    const newArr = [];

    for (let i = 0; i < arr.length; i++) {
        if (callback(arr[i])) {
            newArr.push(arr[i]);
        }
    }

    return newArr;
};

const arrayOriginal = [1, 2, 3, 4, 5];
const novoArray = filtrarArray(arrayOriginal, (elemento) => elemento % 2 === 0);
console.log(novoArray);