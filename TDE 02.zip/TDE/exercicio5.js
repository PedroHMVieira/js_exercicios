const validarDados = (obj, validarObj) => {
    const ehValido = validarObj(obj)
    if(ehValido) return true
    return false
}

const pessoa = {
    nome: "igor"
}

const validarNome = (pessoa) => {
    return pessoa.nome.length > 3
}
const  result = validarDados(pessoa, validarNome)
console.log(result);