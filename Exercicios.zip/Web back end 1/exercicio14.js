function seila(n1,n2){
let soma = 0;
soma = n1+n2;
if(soma%5==0){
    return true
} else{
    return false
}
}

console.log(seila(5,479));