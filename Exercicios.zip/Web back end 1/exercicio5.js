let i = 0;

while(i<10){
    console.log(i+1+'*7='+(i+1)*7);
    i++
}