function eMultiplo(num1,num2){
if(num1%num2==0){
    return true
} else {
    return false
}
}

console.log(eMultiplo(20,10));