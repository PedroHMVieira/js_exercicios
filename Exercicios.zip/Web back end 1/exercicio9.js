function epar(numero){
    if(numero%2==0){
        return true
    } else{
        return false
    }
}

console.log(epar(15));