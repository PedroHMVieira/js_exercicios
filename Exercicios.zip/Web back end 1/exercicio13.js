let numero = 0

if(numero<0){
    console.log("é negativo");
}
else if(numero==0){
    console.log("o numero é 0");
}
else{
    console.log("o numero e positivo");
}