function menorNumero(n1,n2,n3){
    if(n1<n2 && n1<n3){
        return n1;
    }
    if(n2<n3 && n2<n1){
        return n2;
    } else{
        return n3
    }
}

console.log(menorNumero(4,2,4));