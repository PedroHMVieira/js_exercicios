let par = 0;

for(let i = 0; i <101; i++){
    if(i%2==0){
        par=par+i;
    }
}

console.log(par);
