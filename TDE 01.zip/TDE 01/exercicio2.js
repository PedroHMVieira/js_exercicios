let saldo = -17

if(saldo < 0){
    console.log('Saldo negativo');
} else{
    console.log('Saldo positivo');
}
