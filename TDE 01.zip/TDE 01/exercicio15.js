let celsius = 15;

let fahrenheit = celsius*1.8+32;

console.log(fahrenheit);