for(let i=0; i<11; i++){
    console.log(i);}