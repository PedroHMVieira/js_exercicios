function ehNegativo(numero){
if(numero<0){
    return false
} else{
    return true
}
}

console.log(ehNegativo(15));