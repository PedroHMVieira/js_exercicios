//print
console.log("Hello world")

//variavel

let teste = 10
var nome = "igor"
const ehPar = true

teste = 12

console.log(teste)

console.log(2+2)
console.log(2-2)
console.log(2*2)
console.log(2/2)
console.log(2%2)
console.log(parseInt(5/2))

//verdade e verdade
console.log(true && true)

//verdade ou verdade

console.log(true || true);

//comparações
console.log(1 == 1)
console.log(1 == "1")
console.log(1 != 2)
console.log(1 >= 2)
console.log(1 <= 0)

// se sim / se nao

if (teste > 11){
    console.log("Teste é maior");
} else {
    "´Teste é menor"
}

//selecionar

const code = 1;
switch(code){
    case 1:
        console.log("Ligar tv")
        break
    case 2:
        console.log("Desligar tv")
        break
    default:
        console.log("Sei lá");

}

//laço de repetição

for (let i = 0; i < 10; i++){
    console.log(i);
}

let i = 10;
while(i<30){
    console.log(i);
    i*=2 // i = i*2
}


function  soma(a,b){
    return a + b
}

let a = 10;
let b = 10;




